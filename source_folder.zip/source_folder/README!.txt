u will have to download the pretrained models from:

https://github.com/deezer/spleeter/releases

also check "background_music" directory to further instructions
