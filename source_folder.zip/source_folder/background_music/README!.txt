to change the background music simply put another .wav file in the folder and remove the former .wav file.

!!!there must be only one .wav file in the folder or it crashes!!!

